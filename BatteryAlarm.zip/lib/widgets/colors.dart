import 'package:flutter/material.dart';

Color backGround = const Color(0xFF000000);
Color foreGround = const Color(0xFF252525);
Color animation = const Color(0xFF69e04b);
Color textColor = const Color(0xFFffffff);
Color themeColor = const Color(0xFFf74a5e);
Color linesColor = const Color(0xFF6d6d6d) ;
Color newLinesColor = const Color(0xFF8D8B8B);